<?php
// Determine suffix for image
$suffixe =  $this->locale == "fr" ?  "" : "-en";
?>

<script type="text/javascript">
	UrlPlaylist = "<?php echo $wvx ?>"; 
</script>

<script type="text/javascript">
//<![CDATA[   
function popSlide(slide){
       popSlide_height = 480; 
       popSlide_width = 620;
       var top=(screen.height-popSlide_height)/2;
       var left=(screen.width-popSlide_width)/2;
       window.open(slide,"","WIDTH=" + popSlide_width +",HEIGHT=" + popSlide_height + ",left=" +left+ ",top="+top); 
}
var current = "";
var current_lcid = ""; 

function noPlugin(){
       document.getElementById("messageInstall").style.display = "block";
}                                   
function addbookmark() { 
	if ( navigator.appName != 'Microsoft Internet Explorer' ) {   
    	window.sidebar.addPanel("<?php echo addslashes(  $program->title )?>","<?php echo $program->getHtmlUrl() ?>","");    
	}
	else {     
    	window.external.AddFavorite("<?php echo $program->getHtmlUrl() ?>","<?php echo addslashes(  $program->title) ?>");    
    } 
}
function fermer() {
    document.getElementById("zoneDynamique").style.display = "none";
    MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    current = "";
}
function fermer3() {
    
    MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    current = "";
}
function fermer2() {
    document.getElementById("zoneDynamique").style.display = "none";
    current = "";
}
function changeContenuTitre(rubrique) {
    
    current =   rubrique;
    if (rubrique == "langues") {        
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-langues<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltiplangue") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        document.getElementById('contenuDynamique').innerHTML = "";
        var v = document.getElementById("hiddenLangue").innerHTML;     
        document.getElementById('contenuDynamique').innerHTML = v;
        if(current_lcid != ""){
            $('.lang_'+current_lcid).attr("checked","checked");
        }else{
             $('.lang_'+1036).attr("checked","checked");                    
        }
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues-over.gif',0);
    } else  if (rubrique == "informations") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-informations<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltipinfos") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = document.getElementById("hiddenInfos").innerHTML; 
        document.getElementById('contenuDynamique').innerHTML = v;
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos-over.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    } else  if (rubrique == "favoris") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-favoris<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltipfavoris") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';          
        var v = document.getElementById("hiddenFavoris").innerHTML;
          document.getElementById('contenuDynamique').innerHTML = v;
          MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris-over.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    } else if (rubrique == "email") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-email<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltipemail") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = '<div class="mail"><?php echo $this->translate("recipients") ?> :  <br/><textarea name="destinataires" id="destinataires" cols="38" rows="2" title="<?php echo $this->translate("noticeemail")?>"></textarea><br/><?php echo $this->translate("yourmessage") ?> :<br/><textarea name="" id="text" cols="38" rows="8" title="<?php echo $this->translate("tipyourmessage") ?>"></textarea><br/><input type="button" class="submit" onclick="" value="<?php echo $this->translate("send") ?>"></div>';                                                          
        document.getElementById('contenuDynamique').innerHTML = "";
        document.getElementById('contenuDynamique').innerHTML = v;  
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail-over.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    } else if (rubrique == "chapitres") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-chapitres<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltipchapters") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = document.getElementById("hiddenChapters").innerHTML;
        document.getElementById('contenuDynamique').innerHTML = v;  
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres-over.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);  
    } else if (rubrique == "dernieresVideos") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-dernieres-videos<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltiplastvids") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = document.getElementById("hiddenVideoListe").innerHTML;
        document.getElementById('contenuDynamique').innerHTML = v;  
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos-over.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    } else if (rubrique == "videosAssociees") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-videos-liees<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltiplinkedvids") ?>" width="248" height="27" /><a href="<?php $urlwvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = document.getElementById("hiddenSerie").innerHTML; 
        document.getElementById('contenuDynamique').innerHTML = v;  
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees-over.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0); 
    } else if (rubrique == "integration") {
        document.getElementById("titre").innerHTML = '<img src="<?php echo THEME_PATH ?>/images/onglet-integration<?php echo $suffixe ?>.gif" alt="<?php echo $this->translate("tooltipintegration") ?>" width="248" height="27" /><a href="<?php echo $wvx ?>" title="secours vidéos !"  ><img border="0" width=43" height="27" alt="secours vidéos !" src="<?php echo THEME_PATH ?>/images/picto-bouee.gif" /></a><a href="mailto:video@finances.gouv.fr" title="support utilisateurs"><img  alt="support utilisateurs" src="<?php echo THEME_PATH ?>/images/bouton-fermer.gif" alt="" width="35" height="27" border="0"/></a>';
        var v = document.getElementById("hiddenIntegration").innerHTML;  
        document.getElementById('contenuDynamique').innerHTML = v;
        MM_swapImage('picto1','','<?php echo THEME_PATH ?>/images/picto-infos.gif','picto2','','<?php echo THEME_PATH ?>/images/picto-favoris.gif','picto3','','<?php echo THEME_PATH ?>/images/picto-mail.gif','picto4','','<?php echo THEME_PATH ?>/images/picto-chapitres.gif','picto5','','<?php echo THEME_PATH ?>/images/picto-dernieres-videos.gif','picto6','','<?php echo THEME_PATH ?>/images/picto-videos-liees.gif','picto7','','<?php echo THEME_PATH ?>/images/picto-integrer-over.gif','picto8','','<?php echo THEME_PATH ?>/images/picto-langues.gif',0);
    }
    document.getElementById("zoneDynamique").style.display = "block";       
}



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function mailto(idSess,dest,text,clefprog,clef){
    if(dest == ""){
      alert("<?php echo $this->translate("errordest")?>");return false
    }
    var xhr = null ;
    var scriptName = "/dynamic/catal/mailto.php?idSess="+idSess;
    var sync = true;

    xhr = getXhr();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && xhr.status == 200){
            resp = xhr.responseText;
            if(resp == "true"){
                document.getElementById('contenuDynamique').innerHTML = "<p><?php echo $this->translate("messagesend") ?></p>";
            }
        }
    }
    xhr.open("POST",scriptName,sync);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.send("dest="+ dest +"&text="+ text+"&clefprog="+ clefprog + "&clef="+ clef);
}

var pop_videolist = null;
var url_videolist = '' ;

function popupVideolist(){
	<?php if(isset($this->params["videolist"])) :?>
	    pop_videolist =  window.open ('<?php echo $this->params["videolist"] ?>', 'Videolist', config='height=600, width=620, toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, directories=no, status=yes');
   <?php else: ?>
   pop_videolist =  window.open ('<?php echo BASE_URL?>watch/videolist/index/keypub/<?php echo $this->keypub ?>/viewcode/<?php echo $this->viewcode ?>', 'Videolist', config='height=600, width=620, toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, directories=no, status=yes');
   <?php endif; ?>	   
	    pop_videolist.focus();
	}
		
function changeSheet(sheet){
    url_videolist = pop_videolist.location.href ;
    pop_videolist.close();
    document.location.href = sheet + "?videolist="+urlencode(url_videolist);
}

function actionOnDiv(divToStyle,name){ 
    
        $("div[id*=tag] .chapter_description").css("background","none");
        $("div[id=" + divToStyle + "] .chapter_description" ).css("background","#fff  url(<?php echo THEME_PATH ?>/images/fond-titre-tags.gif) bottom left repeat-x");
        //$("div[id=" + divToStyle + "] .chapter_description" ).css("background","#fff  url(<?php echo THEME_PATH ?>/images/playing.gif) top left repeat-y");
        if(current == "chapitres" ){
            var v = document.getElementById("hiddenChapters").innerHTML;
            document.getElementById('contenuDynamique').innerHTML = v; 
        }
}
function urlencode(str) {
    str = escape(str);
    str = str.replace('+', '%2B');
    str = str.replace('%20', '+');
    str = str.replace('*', '%2A');
    str = str.replace('/', '%2F');
    str = str.replace('@', '%40'); 
    return str;
}
function urldecode(str) {
    str = str.replace("+", " ");
    str = unescape(str);
    return str;
} 
function loadTrack(step){
    PlayAt(0,0);
}


//]]>
</script>
