<?php
function Tronquer_Texte($text, $max , $replacement = "...")
{
     
    if (strlen($text) > $max)
    {
        $text = substr($text, 0, $max);
        $lastSpace = strrpos($text, " ");
        if($lastSpace)
        $text = substr($text, 0, $lastSpace).$replacement;
    }
    return $text;
}

function CleanTc($text){

    if(!preg_match("/\d{2}:*(\d{2})*:*(\d{2})*:*(\d{2})*/",$text)) return $text;

    if($text == "00:00:00:00") return "";
    $timecode = explode(":", $text);
    $timecodeclean = "";

    if( isset($timecode[0]) && $timecode[0] != "00"){
        if(substr($timecode[0],0,1)=="0") $timecode[0] = str_replace("0","",$timecode[0]);
        $timecodeclean .= $timecode[0]."h";
    }
    if(isset($timecode[1]) && $timecode[1] != "00"){
        if(substr($timecode[1],0,1)=="0") $timecode[1] = str_replace("0","",$timecode[1]);
        $timecodeclean .= $timecode[1]."'";
    }
    if(isset($timecode[2]) && $timecode[2] != "00"){
        if(substr($timecode[2],0,1)=="0") $timecode[2] = str_replace("0","",$timecode[2]);
        $timecodeclean .= $timecode[2]."''";
    }

    return  $timecodeclean;
}
function  getFilename($path){
    $part = explode("/",$path);
    return $part[(sizeof($part)-1)];
}