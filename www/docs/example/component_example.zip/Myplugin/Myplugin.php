<?php
/**
 * @author Cyril HOLZER
 * @desc
 */
class Plugins_Myplugin extends Zend_Controller_Plugin_Abstract
{

    public function __construct(){
        
    }
    public function preDispatch (Zend_Controller_Request_Abstract $request)
    {
          
    }
   
}
